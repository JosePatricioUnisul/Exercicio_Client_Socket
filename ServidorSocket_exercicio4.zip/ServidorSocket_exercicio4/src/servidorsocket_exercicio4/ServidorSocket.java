package servidorsocket_exercicio4;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.ServerSocket;
import java.net.Socket;

/**
 *
 * @author josep
 */
public class ServidorSocket {

    private ControladorVoo controlador;

    public ServidorSocket() {
        controlador = new ControladorVoo();
    }

    public void rodarServidor() throws IOException {

        ServerSocket ss = new ServerSocket(4999);

        System.out.println("Servidor pronto para aceitar conexões...");


        while (true) {

            Socket s = ss.accept();
            System.out.println("Cliente Conectado");

            new Thread(() -> {
                try {
                    
                    InputStreamReader in = new InputStreamReader(s.getInputStream());
                    BufferedReader bf = new BufferedReader(in);

                    String str = bf.readLine();

                    System.out.println("Mensagem do cliente: " + str);

                    String resultadoBusca = calcularCodigoStatus(str);


                    PrintWriter pr = new PrintWriter(s.getOutputStream());
                    pr.println(resultadoBusca);
                    pr.flush();


                    s.close();
                    
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }).start();
        }
    }

    public String calcularCodigoStatus(String str) {

        String[] partes = str.split(";");            

        if (partes.length >= 3) {
            
            String operacao = partes[0];
            String codigoVoo = partes[1];
            int numeroAssento = Integer.parseInt(partes[2]);

            
            System.out.println("Operacao: " + operacao);
            System.out.println("Codigo do voo: " + codigoVoo);
            System.out.println("Numero do assento: " + numeroAssento);

            int result;

            if (operacao.equals("C")) {
                result = controlador.verificarStatus(codigoVoo, numeroAssento);
            } else {
                result = controlador.marcarVoo(codigoVoo, numeroAssento);
            }

            String output = "";

            if (result == 1) {
                output = "Assento indisponível";
            } else if (result == 2) {
                output = "Assento Inexistente";
            } else if (result == 3) {
                output = "Voo inexistente";
            } else if (result == 0) {
                output = "Voo disponivel";
            } else {
                output = "Marcaçao realizada";
            }
            return output;

        } else {
            System.out.println("Formato de entrada inválido.");
        }

       return "Erro na requisicao";
    }

}
