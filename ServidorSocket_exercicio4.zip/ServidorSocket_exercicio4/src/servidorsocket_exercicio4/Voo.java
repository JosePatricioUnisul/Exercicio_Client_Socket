/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package servidorsocket_exercicio4;

import java.util.ArrayList;

/**
 *
 * @author josep
 */
public class Voo {

    private ArrayList<Assento> assentos;
    private String codigoVoo;
    public static final int NUMERO_DE_ASSENTOS = 50;

    public Voo(String codigoVoo) {
        this.codigoVoo = codigoVoo;
        assentos = new ArrayList<>();
        
        
        for (int i = 0; i < NUMERO_DE_ASSENTOS; i++) {
            Assento assento = new Assento(i + 1);
           assento.setDisponivel(true);
            assentos.add(assento);
        }
    }

    public ArrayList<Assento> getAssentos() {
        return assentos;
    }

    public void setAssentos(ArrayList<Assento> assentos) {
        this.assentos = assentos;
    }

    public String getCodigoVoo() {
        return codigoVoo;
    }

    public void setCodigoVoo(String codigoVoo) {
        this.codigoVoo = codigoVoo;
    }

    public Assento procurarAssento(int numeroAssento) {
        for (Assento assento : assentos) {
            if (assento.getNumero() == numeroAssento) {
                return assento;
            }
        }
        return null;
    }

}
