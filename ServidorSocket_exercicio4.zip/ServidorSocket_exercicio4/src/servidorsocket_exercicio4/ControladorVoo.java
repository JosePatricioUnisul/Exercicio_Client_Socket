package servidorsocket_exercicio4;

import java.util.ArrayList;
import servidorsocket_exercicio4.Assento;
import servidorsocket_exercicio4.Voo;

public class ControladorVoo {
    
    private ArrayList<Voo> voos;
    public static final int NUMERO_DE_VOOS = 10;

    public ControladorVoo() {
        voos = new ArrayList<>();

        for (int i = 0; i < NUMERO_DE_VOOS; i++) {
            Voo voo = new Voo("A" + (i + 1));
            voos.add(voo);
        }
    }

    public synchronized int verificarStatus(String codigoVoo, int assento) {
        Voo voo = procurarVoo(codigoVoo);
        if (voo == null) {
            return 3; // Voo inexistente
        } else {
            Assento assentoObj = voo.procurarAssento(assento);
            if (assentoObj == null) {
                return 2; // Assento inexistente
            } else {
                if (assentoObj.getDisponivel()) {
                    return 0; // Voo disponível
                } else {
                    return 1; // Assento indisponível
                }
            }
        }
    }

    public synchronized int marcarVoo(String codigoVoo, int assento) {
        Voo voo = procurarVoo(codigoVoo);
        if (voo == null) {
            return 3; // Voo inexistente
        } else {
            Assento assentoObj = voo.procurarAssento(assento);
            if (assentoObj == null) {
                return 2; // Assento inexistente
            } else {
                if (assentoObj.getDisponivel()) {
                    assentoObj.setDisponivel(false);
                    return 4; // Marcação realizada
                } else {
                    return 1; // Assento indisponível
                }
            }
        }
    }

    public synchronized Voo procurarVoo(String codigoVoo) {
        for (Voo voo : voos) {
            if (voo.getCodigoVoo().equals(codigoVoo)) {
                return voo;
            }
        }
        return null;
    }
}
